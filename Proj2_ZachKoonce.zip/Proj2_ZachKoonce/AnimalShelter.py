from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""
    
    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # acces the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apaprto Enviroment
        #
        # I copied this blurb from the example directly so
        # that I would also have a reference for better understanding
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30563
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        #self.client = MongoClient('mongodb://aacuser:test123@nv-desktop-services.apparto.com:30564')
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
    #
    # Method for insterting (creating)
    #
    def create (self, data):
        if data is not None:
            insertCheck = self.database.animals.insert_one(data) #data should be dictionary
            if insertCheck != 0: return True
            else : return False
        else:
            raise Exception("Noting to save, because data parameter is empty")
    #
    # Method for searching (reading)
    #
    def read(self, query):
        try:
            result = self.collection.find(query)
            return list(result)
        except: 
            ("Something went wrong in your search")
            return -1
    #    
    # Method for updating
    #
    def update(self, query, data):
        try:
            toUpdate = self.database.animals.update_many(query, {'$set' : data})
            return toUpdate.modified_count
        except: 
            ("Something went wrong in your search")
            return -1
    #    
    # Method for deleting
    #
    def delete(self, query):
        try:
            toDelete = self.database.animals.delete_many(query)
            return toDelete.deleted_count
        except: 
            ("Something went wrong in your search")
            return -1
